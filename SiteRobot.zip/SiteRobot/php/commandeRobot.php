<?php
shell_exec ('mkdir "TEST1"');
echo('test');

?>